package com.devst.juegos;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.firestore.FirebaseFirestore; // CAMBIO IMPORTANTE

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

public class RegisterActivity extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 1;
    private static final int STORAGE_PERMISSION_CODE = 101;

    private EditText emailField, passwordField, usernameField, confirmPasswordField;
    private ImageView profileImageView;
    private Button registerButton, selectImageButton;
    private FirebaseAuth mAuth;
    private FirebaseFirestore db; // CAMBIO IMPORTANTE
    private Uri imageUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance(); // CAMBIO IMPORTANTE

        usernameField = findViewById(R.id.username);
        emailField = findViewById(R.id.email);
        passwordField = findViewById(R.id.password);
        confirmPasswordField = findViewById(R.id.confirm_password);
        profileImageView = findViewById(R.id.profile_image);
        registerButton = findViewById(R.id.register_button);
        selectImageButton = findViewById(R.id.select_image_button);

        selectImageButton.setOnClickListener(v -> checkPermissionAndOpenFileChooser());
        registerButton.setOnClickListener(v -> createAccount());
    }

    private void createAccount() {
        String username = usernameField.getText().toString().trim();
        String email = emailField.getText().toString().trim();
        String password = passwordField.getText().toString().trim();

        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(email) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Por favor, complete todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser user = mAuth.getCurrentUser();
                        if (user == null) {
                            Toast.makeText(this, "Error al crear el usuario.", Toast.LENGTH_SHORT).show();
                            return;
                        }

                        Uri localPhotoUri = null;
                        if (imageUri != null) {
                            localPhotoUri = guardarImagenInterna(imageUri, user.getUid());
                        }

                        saveUserData(user, username, email, localPhotoUri);

                    } else {
                        Toast.makeText(RegisterActivity.this, "Error en el registro: " + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
    }

    private void saveUserData(FirebaseUser user, String username, String email, @Nullable Uri localPhotoUri) {
        UserProfileChangeRequest.Builder profileUpdatesBuilder = new UserProfileChangeRequest.Builder()
                .setDisplayName(username);

        String photoPath = null;
        if (localPhotoUri != null) {
            profileUpdatesBuilder.setPhotoUri(localPhotoUri);
            photoPath = localPhotoUri.toString();
        }

        user.updateProfile(profileUpdatesBuilder.build());

        Map<String, Object> userData = new HashMap<>();
        userData.put("username", username);
        userData.put("email", email);
        userData.put("profileImageUrl", photoPath != null ? photoPath : "");

        // CAMBIO IMPORTANTE: Usar Firestore
        db.collection("users").document(user.getUid()).set(userData)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(RegisterActivity.this, "Usuario registrado con éxito.", Toast.LENGTH_SHORT).show();
                    finish();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(RegisterActivity.this, "Error al guardar datos en Firestore.", Toast.LENGTH_LONG).show();
                });
    }

    // --- El resto de los métodos (permisos, guardado de imagen, etc.) se mantienen igual ---

    private Uri guardarImagenInterna(Uri sourceUri, String userId) {
        try {
            InputStream in = getContentResolver().openInputStream(sourceUri);
            File dir = new File(getFilesDir(), "perfil");
            if (!dir.exists()) {
                dir.mkdirs();
            }
            File outFile = new File(dir, "perfil_" + userId + ".jpg");

            try (OutputStream out = new FileOutputStream(outFile)) {
                byte[] buf = new byte[1024];
                int len;
                while ((len = in.read(buf)) > 0) {
                    out.write(buf, 0, len);
                }
            }
            in.close();
            return Uri.fromFile(outFile);
        } catch (Exception e) {
            Log.e("RegisterActivity", "Error guardando imagen interna", e);
            Toast.makeText(this, "Error al guardar la imagen.", Toast.LENGTH_SHORT).show();
            return null;
        }
    }
    
    private void checkPermissionAndOpenFileChooser() {
        String permission;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permission = Manifest.permission.READ_MEDIA_IMAGES;
        } else {
            permission = Manifest.permission.READ_EXTERNAL_STORAGE;
        }

        if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, permission)) {
                new AlertDialog.Builder(this)
                        .setTitle("Permiso Necesario")
                        .setMessage("Se necesita acceso a las fotos para seleccionar una imagen de perfil.")
                        .setPositiveButton("Entendido", (dialog, which) -> {
                            ActivityCompat.requestPermissions(this, new String[]{permission}, STORAGE_PERMISSION_CODE);
                        })
                        .setNegativeButton("Cancelar", (dialog, which) -> dialog.dismiss())
                        .create().show();
            } else {
                ActivityCompat.requestPermissions(this, new String[]{permission}, STORAGE_PERMISSION_CODE);
            }
        } else {
            openFileChooser();
        }
    }

    private void openFileChooser() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }
    
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == STORAGE_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openFileChooser();
            } else {
                 if (!ActivityCompat.shouldShowRequestPermissionRationale(this, permissions[0])) {
                    new AlertDialog.Builder(this)
                            .setTitle("Permiso Denegado Permanentemente")
                            .setMessage("Has denegado el permiso. Para seleccionar una foto, debes activarlo manualmente en los ajustes de la aplicación.")
                            .setPositiveButton("Ir a Ajustes", (dialog, which) -> {
                                Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                                Uri uri = Uri.fromParts("package", getPackageName(), null);
                                intent.setData(uri);
                                startActivity(intent);
                            })
                            .setNegativeButton("Cancelar", null)
                            .create().show();
                } else {
                    Toast.makeText(this, "Permiso denegado. No se puede seleccionar una imagen.", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            imageUri = data.getData();
            profileImageView.setImageURI(imageUri);
        }
    }
}
