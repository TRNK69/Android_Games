package com.devst.juegos;

import android.util.Log;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class KeysScraper {

    private static final String TAG = "KeysScraper";
    // URL actualizada para apuntar directamente a la página con contenido
    private static final String URL = "https://www.keysforgames.cl/games/steam-games/?page=2";

    public static List<Game> scrape() {
        List<Game> gamesList = new ArrayList<>();
        try {
            Log.d(TAG, "Iniciando scraping de: " + URL);
            Document doc = Jsoup.connect(URL).get();
            Log.d(TAG, "HTML descargado con éxito.");

            Elements items = doc.select("li.product-item");
            Log.d(TAG, "Se encontraron " + items.size() + " elementos con 'li.product-item'.");

            for (Element item : items) {
                try {
                    String nombre = item.select("strong.product-item-name a").text();
                    String imagen = item.select("img.product-image-photo").attr("src");
                    String enlace = item.select("a.product-item-link").attr("href");
                    String precio = item.select("span.price").first().text();
                    String tienda = "Keys for Games";

                    if (!nombre.isEmpty() && !precio.isEmpty()) {
                        gamesList.add(new Game(nombre, imagen, precio, tienda, enlace));
                        Log.d(TAG, "Juego encontrado: " + nombre + " | Precio: " + precio);
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Error parseando un item", e);
                }
            }
        } catch (IOException e) {
            Log.e(TAG, "Error al hacer scraping en " + URL, e);
            return null;
        }
        return gamesList;
    }
}
