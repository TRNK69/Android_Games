package com.devst.juegos;

import android.util.Log;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class DealScraper {

    private static final String TAG = "DealScraper";
    private static final String URL = "https://isthereanydeal.com/deals/";

    public static List<Game> scrape() {
        List<Game> gamesList = new ArrayList<>();
        try {
            Log.d(TAG, "Iniciando scraping de: " + URL);
            Document doc = Jsoup.connect(URL).userAgent("Mozilla/5.0").get();
            Log.d(TAG, "HTML descargado con éxito.");

            // Selector corregido y definitivo para la nueva página
            Elements items = doc.select("div.list-view-item");
            Log.d(TAG, "Se encontraron " + items.size() + " elementos con 'div.list-view-item'.");

            for (Element item : items) {
                try {
                    String nombre = item.select("a.deal-title").text();
                    String precio = item.select(".deal-price-val").text();
                    String tienda = item.select("a.shop-tag-name").text();
                    String imagen = item.select("img.deal-image").attr("data-src");
                    String enlace = "https://isthereanydeal.com" + item.select("a.deal-title").attr("href");

                    if (!nombre.isEmpty() && !precio.isEmpty()) {
                        gamesList.add(new Game(nombre, imagen, precio, tienda, enlace));
                        Log.d(TAG, "Juego encontrado: " + nombre);
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Error parseando un item", e);
                }
            }
        } catch (IOException e) {
            Log.e(TAG, "Error al hacer scraping en " + URL, e);
            return null;
        }
        return gamesList;
    }
}
