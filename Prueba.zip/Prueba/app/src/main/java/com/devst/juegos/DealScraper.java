package com.devst.juegos;

import android.util.Log;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.WriteBatch;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class DealScraper {

    private static final String TAG = "DealScraper";
    private static final String URL = "https://isthereanydeal.com/deals/";

    public static List<Game> scrape() {
        List<Game> gamesList = new ArrayList<>();
        try {
            Log.d(TAG, "Iniciando scraping de: " + URL);
            Document doc = Jsoup.connect(URL).userAgent("Mozilla/5.0").get();
            Log.d(TAG, "HTML descargado con éxito.");

            Elements items = doc.select("div.list-view-item");
            Log.d(TAG, "Se encontraron " + items.size() + " elementos.");

            for (Element item : items) {
                try {
                    String nombre = item.select("a.deal-title").text();
                    String precio = item.select(".deal-price-val").text();
                    String tienda = item.select("a.shop-tag-name").text();
                    String imagen = item.select("img.deal-image").attr("data-src");
                    String enlace = "https://isthereanydeal.com" + item.select("a.deal-title").attr("href");

                    if (!nombre.isEmpty() && !precio.isEmpty()) {
                        gamesList.add(new Game(nombre, imagen, precio, tienda, enlace));
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Error parseando un item", e);
                }
            }
        } catch (IOException e) {
            Log.e(TAG, "Error al hacer scraping en " + URL, e);
            return null; // Devuelve null si no se pudo conectar
        }

        // Después de obtener los juegos, guárdalos en Firestore
        if (!gamesList.isEmpty()) {
            saveGamesToFirestore(gamesList);
        }

        return gamesList;
    }

    private static void saveGamesToFirestore(List<Game> gamesList) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        // 1. Borra todos los documentos antiguos de la colección 'games'
        db.collection("games").get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                WriteBatch deleteBatch = db.batch();
                for (QueryDocumentSnapshot document : task.getResult()) {
                    deleteBatch.delete(document.getReference());
                }
                deleteBatch.commit().addOnCompleteListener(deleteTask -> {
                    if (deleteTask.isSuccessful()) {
                        Log.d(TAG, "Colección 'games' antigua eliminada con éxito.");

                        // 2. Añade los nuevos juegos a la colección
                        WriteBatch addBatch = db.batch();
                        for (Game game : gamesList) {
                            DocumentReference docRef = db.collection("games").document(); // Crea un documento con ID automático
                            addBatch.set(docRef, game);
                        }
                        addBatch.commit()
                                .addOnSuccessListener(aVoid -> Log.d(TAG, "Nuevos juegos guardados en Firestore con éxito."))
                                .addOnFailureListener(e -> Log.e(TAG, "Error al guardar los nuevos juegos en Firestore", e));

                    } else {
                        Log.e(TAG, "Error al eliminar la colección 'games' antigua", deleteTask.getException());
                    }
                });
            } else {
                Log.e(TAG, "Error obteniendo la colección 'games' para borrar", task.getException());
            }
        });
    }
}
