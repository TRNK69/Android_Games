package com.devst.juegos;

public class Game {
    private String nombre;
    private String imagenUrl;
    private String precio;
    private String tienda;
    private String url;

    // Constructor vacío requerido para Firebase
    public Game() {}

    public Game(String nombre, String imagenUrl, String precio, String tienda, String url) {
        this.nombre = nombre;
        this.imagenUrl = imagenUrl;
        this.precio = precio;
        this.tienda = tienda;
        this.url = url;
    }

    // Getters y Setters
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getImagenUrl() { return imagenUrl; }
    public void setImagenUrl(String imagenUrl) { this.imagenUrl = imagenUrl; }
    public String getPrecio() { return precio; }
    public void setPrecio(String precio) { this.precio = precio; }
    public String getTienda() { return tienda; }
    public void setTienda(String tienda) { this.tienda = tienda; }
    public String getUrl() { return url; }
    public void setUrl(String url) { this.url = url; }
}
