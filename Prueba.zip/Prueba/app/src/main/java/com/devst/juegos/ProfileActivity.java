package com.devst.juegos;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.firestore.FirebaseFirestore; // CAMBIO IMPORTANTE

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

public class ProfileActivity extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 1;
    private static final int STORAGE_PERMISSION_CODE = 101;

    private EditText emailEditText, usernameEditText;
    private TextInputEditText passwordEditText;
    private ImageView profileImageView;
    private Button updateButton, deleteButton, logoutButton;
    private FirebaseAuth mAuth;
    private FirebaseUser currentUser;
    private FirebaseFirestore db; // CAMBIO IMPORTANTE
    private Uri imageUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        mAuth = FirebaseAuth.getInstance();
        currentUser = mAuth.getCurrentUser();
        db = FirebaseFirestore.getInstance(); // CAMBIO IMPORTANTE

        usernameEditText = findViewById(R.id.profile_username);
        emailEditText = findViewById(R.id.profile_email);
        passwordEditText = findViewById(R.id.profile_password);
        profileImageView = findViewById(R.id.profile_image);
        updateButton = findViewById(R.id.button_update_profile);
        deleteButton = findViewById(R.id.button_delete_account);
        logoutButton = findViewById(R.id.button_logout_profile);

        if (currentUser != null) {
            usernameEditText.setText(currentUser.getDisplayName());
            emailEditText.setText(currentUser.getEmail());
            if (currentUser.getPhotoUrl() != null) {
                Glide.with(this).load(currentUser.getPhotoUrl()).into(profileImageView);
            }
        } else {
            goToLogin();
            return;
        }

        profileImageView.setOnClickListener(v -> checkPermissionAndOpenFileChooser());
        updateButton.setOnClickListener(v -> {
            if (!TextUtils.isEmpty(passwordEditText.getText().toString())) {
                showReauthenticationDialog(false);
            } else {
                updateUserProfile();
            }
        });
        deleteButton.setOnClickListener(v -> showReauthenticationDialog(true));
        logoutButton.setOnClickListener(v -> logout());
    }

    private void updateUserProfile() {
        String newUsername = usernameEditText.getText().toString().trim();
        String newPassword = passwordEditText.getText().toString().trim();

        if (TextUtils.isEmpty(newUsername)) {
            usernameEditText.setError("El nombre de usuario no puede estar vacío");
            return;
        }

        Uri localPhotoUri = null;
        if (imageUri != null) {
            localPhotoUri = guardarImagenInterna(imageUri, currentUser.getUid());
        }

        updateAuthAndDb(newUsername, newPassword, localPhotoUri);
    }

    private void updateAuthAndDb(String newUsername, String newPassword, @Nullable Uri newLocalPhotoUri) {
        UserProfileChangeRequest.Builder profileUpdatesBuilder = new UserProfileChangeRequest.Builder()
                .setDisplayName(newUsername);

        if (newLocalPhotoUri != null) {
            profileUpdatesBuilder.setPhotoUri(newLocalPhotoUri);
        }

        currentUser.updateProfile(profileUpdatesBuilder.build());

        Map<String, Object> updates = new HashMap<>();
        updates.put("username", newUsername);
        if (newLocalPhotoUri != null) {
            updates.put("profileImageUrl", newLocalPhotoUri.toString());
        }

        // CAMBIO IMPORTANTE: Usar Firestore
        db.collection("users").document(currentUser.getUid()).update(updates)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(ProfileActivity.this, "Perfil actualizado con éxito", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(ProfileActivity.this, "Error al actualizar los datos.", Toast.LENGTH_SHORT).show();
                });

        if (!TextUtils.isEmpty(newPassword)) {
            if (newPassword.length() < 6) {
                passwordEditText.setError("La contraseña debe tener al menos 6 caracteres");
                return;
            }
            currentUser.updatePassword(newPassword).addOnCompleteListener(task -> {
                if (!task.isSuccessful()) {
                    Toast.makeText(ProfileActivity.this, "Error al actualizar la contraseña", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    private void deleteUserAccount() {
        // CAMBIO IMPORTANTE: Usar Firestore
        db.collection("users").document(currentUser.getUid()).delete()
                .addOnSuccessListener(aVoid -> {
                    // Una vez borrado el documento de Firestore, borra el usuario de Auth
                    currentUser.delete().addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            Toast.makeText(ProfileActivity.this, "Cuenta borrada con éxito", Toast.LENGTH_SHORT).show();
                            goToLogin();
                        } else {
                            Toast.makeText(ProfileActivity.this, "Error al borrar la cuenta. Intenta iniciar sesión de nuevo.", Toast.LENGTH_LONG).show();
                        }
                    });
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(ProfileActivity.this, "Error al borrar los datos del perfil.", Toast.LENGTH_LONG).show();
                });
    }
    
    // --- El resto de los métodos se mantienen igual ---

    private Uri guardarImagenInterna(Uri sourceUri, String userId) {
        try {
            InputStream in = getContentResolver().openInputStream(sourceUri);
            File dir = new File(getFilesDir(), "perfil");
            if (!dir.exists()) {
                dir.mkdirs();
            }
            File outFile = new File(dir, "perfil_" + userId + ".jpg");
            try (OutputStream out = new FileOutputStream(outFile)) {
                byte[] buf = new byte[1024];
                int len;
                while ((len = in.read(buf)) > 0) {
                    out.write(buf, 0, len);
                }
            }
            in.close();
            return Uri.fromFile(outFile);
        } catch (Exception e) {
            Log.e("ProfileActivity", "Error guardando imagen interna", e);
            Toast.makeText(this, "Error al guardar la imagen.", Toast.LENGTH_SHORT).show();
            return null;
        }
    }

    private void checkPermissionAndOpenFileChooser() {
        String permission;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permission = Manifest.permission.READ_MEDIA_IMAGES;
        } else {
            permission = Manifest.permission.READ_EXTERNAL_STORAGE;
        }

        if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, permission)) {
                new AlertDialog.Builder(this)
                        .setTitle("Permiso Necesario")
                        .setMessage("Se necesita acceso a las fotos para seleccionar una imagen de perfil.")
                        .setPositiveButton("Entendido", (dialog, which) -> {
                            ActivityCompat.requestPermissions(this, new String[]{permission}, STORAGE_PERMISSION_CODE);
                        })
                        .setNegativeButton("Cancelar", (dialog, which) -> dialog.dismiss())
                        .create().show();
            } else {
                ActivityCompat.requestPermissions(this, new String[]{permission}, STORAGE_PERMISSION_CODE);
            }
        } else {
            openFileChooser();
        }
    }

    private void openFileChooser() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == STORAGE_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openFileChooser();
            } else {
                if (!ActivityCompat.shouldShowRequestPermissionRationale(this, permissions[0])) {
                    new AlertDialog.Builder(this)
                            .setTitle("Permiso Denegado Permanentemente")
                            .setMessage("Has denegado el permiso. Para seleccionar una foto, debes activarlo manualmente en los ajustes de la aplicación.")
                            .setPositiveButton("Ir a Ajustes", (dialog, which) -> {
                                Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                                Uri uri = Uri.fromParts("package", getPackageName(), null);
                                intent.setData(uri);
                                startActivity(intent);
                            })
                            .setNegativeButton("Cancelar", null)
                            .create().show();
                } else {
                    Toast.makeText(this, "Permiso denegado. No se puede seleccionar una imagen.", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            imageUri = data.getData();
            Glide.with(this).load(imageUri).into(profileImageView);
        }
    }

    private void showReauthenticationDialog(boolean forDelete) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Confirmar Identidad");
        builder.setMessage("Por seguridad, introduce tu contraseña actual.");

        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        input.setHint("Contraseña actual");
        builder.setView(input);

        builder.setPositiveButton("Confirmar", (dialog, which) -> {
            String password = input.getText().toString();
            if (password.isEmpty()) {
                Toast.makeText(this, "La contraseña no puede estar vacía", Toast.LENGTH_SHORT).show();
                return;
            }
            reauthenticateAndProceed(password, forDelete);
        });
        builder.setNegativeButton("Cancelar", (dialog, which) -> dialog.cancel());
        builder.show();
    }

    private void reauthenticateAndProceed(String currentPassword, boolean forDelete) {
        AuthCredential credential = EmailAuthProvider.getCredential(currentUser.getEmail(), currentPassword);

        currentUser.reauthenticate(credential).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                if (forDelete) {
                    deleteUserAccount();
                } else {
                    updateUserProfile();
                }
            } else {
                Toast.makeText(ProfileActivity.this, "Error: Contraseña incorrecta", Toast.LENGTH_LONG).show();
            }
        });
    }

    private void logout() {
        mAuth.signOut();
        goToLogin();
    }

    private void goToLogin() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
