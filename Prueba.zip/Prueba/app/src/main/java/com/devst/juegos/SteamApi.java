package com.devst.juegos;

import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class SteamApi {

    private static final String TAG = "SteamApi";
    private static final String API_URL = "https://store.steampowered.com/api/featuredcategories/";

    // La interfaz interna ha sido eliminada para usar la versión universal

    public static void fetchSteamDeals(OnDealsFetchedListener listener) {
        new FetchSteamDealsTask(listener).execute();
    }

    private static class FetchSteamDealsTask extends AsyncTask<Void, Void, List<Game>> {

        private OnDealsFetchedListener listener;

        FetchSteamDealsTask(OnDealsFetchedListener listener) {
            this.listener = listener;
        }

        @Override
        protected List<Game> doInBackground(Void... voids) {
            List<Game> gamesList = new ArrayList<>();
            HttpURLConnection urlConnection = null;

            try {
                URL url = new URL(API_URL);
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");

                BufferedReader in = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder content = new StringBuilder();
                String inputLine;
                while ((inputLine = in.readLine()) != null) {
                    content.append(inputLine);
                }
                in.close();

                JSONObject jsonResponse = new JSONObject(content.toString());
                JSONObject specials = jsonResponse.getJSONObject("specials");
                JSONArray items = specials.getJSONArray("items");

                for (int i = 0; i < items.length(); i++) {
                    JSONObject item = items.getJSONObject(i);

                    String name = item.getString("name");
                    String headerImage = item.getString("header_image");
                    String store = "Steam";
                    String appid = String.valueOf(item.getInt("id"));
                    String gameUrl = "https://store.steampowered.com/app/" + appid;

                    String finalPrice;
                    if (item.has("final_price")) {
                        int priceInCents = item.getInt("final_price");
                        if (priceInCents == 0) {
                            finalPrice = "Gratis";
                        } else {
                            double priceValue = priceInCents / 100.0;
                            String currency = item.optString("currency", "");
                            finalPrice = String.format(Locale.US, "%.2f %s", priceValue, currency);
                        }
                    } else {
                        finalPrice = "No disponible";
                    }

                    gamesList.add(new Game(name, headerImage, finalPrice, store, gameUrl));
                }
                return gamesList;

            } catch (Exception e) {
                Log.e(TAG, "Error al obtener o parsear los datos de Steam", e);
                return null;
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
            }
        }

        @Override
        protected void onPostExecute(List<Game> games) {
            if (listener != null) {
                listener.onComplete(games, "Steam");
            }
        }
    }
}
