package com.devst.juegos;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class GameAdapter extends RecyclerView.Adapter<GameAdapter.GameViewHolder> {

    private Context context;
    private List<Game> games;

    public GameAdapter(Context context, List<Game> games) {
        this.context = context;
        this.games = games;
    }

    @NonNull
    @Override
    public GameViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_game, parent, false);
        return new GameViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull GameViewHolder holder, int position) {
        Game game = games.get(position);

        holder.name.setText(game.getNombre());
        holder.price.setText(game.getPrecio());
        holder.store.setText("Tienda: " + game.getTienda());

        Glide.with(context)
                .load(game.getImagenUrl())
                .placeholder(R.drawable.ic_launcher_background)
                .error(R.drawable.boton_bd_presionado)
                .into(holder.image);

        // Al pulsar en el item, ir a la URL de la oferta
        holder.itemView.setOnClickListener(v -> {
            if (game.getUrl() != null && !game.getUrl().isEmpty()) {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(game.getUrl()));
                context.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return games.size();
    }

    public static class GameViewHolder extends RecyclerView.ViewHolder {

        ImageView image;
        TextView name, price, store;

        public GameViewHolder(@NonNull View itemView) {
            super(itemView);
            image = itemView.findViewById(R.id.gameImage);
            name = itemView.findViewById(R.id.gameName);
            price = itemView.findViewById(R.id.gamePrice);
            store = itemView.findViewById(R.id.gameSalePrice); // Reutilizamos este TextView para la tienda
        }
    }
}
