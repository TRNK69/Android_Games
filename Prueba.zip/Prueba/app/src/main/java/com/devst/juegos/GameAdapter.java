package com.devst.juegos;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class GameAdapter extends RecyclerView.Adapter<GameAdapter.GameViewHolder> {

    private Context context;
    private List<Game> games;

    public GameAdapter(Context context, List<Game> games) {
        this.context = context;
        this.games = games;
    }

    @NonNull
    @Override
    public GameViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_game, parent, false);
        return new GameViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull GameViewHolder holder, int position) {
        Game game = games.get(position);

        holder.name.setText(game.getNombre());
        holder.salePrice.setText(game.getPrecio());
        holder.store.setText("Plataforma: " + game.getTienda());

        Glide.with(context)
                .load(game.getImagenUrl())
                .placeholder(R.drawable.ic_launcher_background)
                .error(R.drawable.logo_pc_juegos)
                .into(holder.image);

        holder.itemView.setOnClickListener(v -> {
            if (game.getUrl() != null && !game.getUrl().isEmpty()) {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(game.getUrl()));
                context.startActivity(i);
            } else {
                Toast.makeText(context, "No hay enlace para este juego", Toast.LENGTH_SHORT).show();
            }
        });
        
        // SE HA ELIMINADO LA LÓGICA DE LOS BOTONES
    }

    @Override
    public int getItemCount() {
        return games.size();
    }

    public static class GameViewHolder extends RecyclerView.ViewHolder {

        ImageView image;
        TextView name, salePrice, store;
        // SE HAN ELIMINADO LAS REFERENCIAS A LOS BOTONES

        public GameViewHolder(@NonNull View itemView) {
            super(itemView);
            image = itemView.findViewById(R.id.gameImage);
            name = itemView.findViewById(R.id.gameName);
            salePrice = itemView.findViewById(R.id.gameSalePrice);
            store = itemView.findViewById(R.id.gameStore);
            
            // SE HAN ELIMINADO LOS FINDVIEWBYID DE LOS BOTONES
        }
    }
}
