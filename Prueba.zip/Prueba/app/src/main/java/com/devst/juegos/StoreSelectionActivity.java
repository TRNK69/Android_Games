package com.devst.juegos;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class StoreSelectionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_store_selection);

        CardView steamCard = findViewById(R.id.card_steam);
        CardView epicCard = findViewById(R.id.card_epic_games);

        steamCard.setOnClickListener(v -> {
            openDealsForStore("Steam");
        });

        epicCard.setOnClickListener(v -> {
            openDealsForStore("Epic Games");
        });
    }

    private void openDealsForStore(String storeName) {
        Intent intent = new Intent(this, PrincipalActivity.class);
        intent.putExtra("STORE_NAME", storeName);
        startActivity(intent);
    }
}
