package com.devst.juegos;

import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class EpicApi {

    private static final String TAG = "EpicApi";
    private static final String API_URL = "https://store-site-backend-static-ipv4.ak.epicgames.com/freeGamesPromotions?locale=es-ES&country=ES&allowCountries=ES";

    public static void fetchEpicDeals(OnDealsFetchedListener listener) {
        new FetchEpicDealsTask(listener).execute();
    }

    private static class FetchEpicDealsTask extends AsyncTask<Void, Void, List<Game>> {

        private OnDealsFetchedListener listener;

        FetchEpicDealsTask(OnDealsFetchedListener listener) {
            this.listener = listener;
        }

        @Override
        protected List<Game> doInBackground(Void... voids) {
            Log.d(TAG, "Iniciando búsqueda en segundo plano...");
            List<Game> gamesList = new ArrayList<>();
            HttpURLConnection urlConnection = null;

            try {
                URL url = new URL(API_URL);
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36");

                InputStream inputStream = urlConnection.getInputStream();
                BufferedReader in = new BufferedReader(new InputStreamReader(inputStream));
                StringBuilder content = new StringBuilder();
                String inputLine;
                while ((inputLine = in.readLine()) != null) {
                    content.append(inputLine);
                }
                in.close();

                Log.d(TAG, "Datos JSON recibidos con éxito.");
                JSONObject jsonResponse = new JSONObject(content.toString());
                JSONObject data = jsonResponse.getJSONObject("data");
                JSONObject catalog = data.getJSONObject("Catalog");
                JSONObject searchStore = catalog.getJSONObject("searchStore");
                JSONArray elements = searchStore.getJSONArray("elements");

                for (int i = 0; i < elements.length(); i++) {
                    JSONObject item = elements.getJSONObject(i);

                    boolean isFreeNow = false;
                    JSONObject priceObject = item.optJSONObject("price");
                    if (priceObject != null) {
                        JSONObject totalPrice = priceObject.optJSONObject("totalPrice");
                        if (totalPrice != null && totalPrice.optInt("discountPrice", -1) == 0) {
                            isFreeNow = true;
                        }
                    }

                    if(isFreeNow) {
                        String name = item.getString("title");
                        // ** LA CORRECCIÓN DEFINITIVA ESTÁ AQUÍ **
                        String store = "Epic Games"; // Quitamos el "(Gratis)"
                        
                        String slug = item.optString("productSlug");
                        if(slug.isEmpty()) slug = item.optString("urlSlug");
                        String gameUrl = "https://www.epicgames.com/store/es-ES/p/" + slug.replace("/home", "");

                        String headerImage = "";
                        JSONArray keyImages = item.getJSONArray("keyImages");
                        for (int j = 0; j < keyImages.length(); j++) {
                            if ("OfferImageWide".equals(keyImages.getJSONObject(j).getString("type"))) {
                                headerImage = keyImages.getJSONObject(j).getString("url");
                                break;
                            }
                        }
                        gamesList.add(new Game(name, headerImage, "Gratis", store, gameUrl));
                    }
                }
                Log.d(TAG, "Búsqueda finalizada. Juegos gratuitos encontrados: " + gamesList.size());
                return gamesList;

            } catch (Exception e) {
                Log.e(TAG, "Error en doInBackground. Causa: ", e);
                return null;
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
            }
        }

        @Override
        protected void onPostExecute(List<Game> games) {
            Log.d(TAG, "onPostExecute: A punto de avisar a la pantalla principal.");
            if (listener != null) {
                listener.onComplete(games, "Epic Games");
            }
        }
    }
}
