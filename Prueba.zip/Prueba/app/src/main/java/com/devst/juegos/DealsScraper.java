package com.devst.juegos;

import android.util.Log;
import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class DealsScraper {

    private static final String TAG = "DealsScraper";
    private static final String DEALS_URL = "https://gg.deals/deals/";

    public static List<Game> scrapeDeals() {
        List<Game> dealsList = new ArrayList<>();
        try {
            Log.d(TAG, "Iniciando scraping de: " + DEALS_URL);

            // Disfraz avanzado para simular un navegador real y evitar el error 403
            Document doc = Jsoup.connect(DEALS_URL)
                    .userAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.0")
                    .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8")
                    .header("Accept-Language", "en-US,en;q=0.5")
                    .header("Accept-Encoding", "gzip, deflate, br")
                    .header("Connection", "keep-alive")
                    .referrer("https://www.google.com")
                    .get();

            Log.d(TAG, "HTML descargado con éxito.");

            Elements items = doc.select("div.deal-list-item");
            Log.d(TAG, "Se encontraron " + items.size() + " elementos de ofertas.");

            for (Element item : items) {
                try {
                    String title = item.select("a.deal-list-item-title").text();
                    String price = item.select("span.price-inner").text();
                    String store = item.select("span.shop-name").text();
                    String imageUrl = item.select("picture > img").attr("src");
                    String dealUrl = "https://gg.deals" + item.select("a.deal-list-item-title").attr("href");

                    if (!title.isEmpty() && !price.isEmpty()) {
                        dealsList.add(new Game(title, imageUrl, price, store, dealUrl));
                        Log.d(TAG, "Oferta encontrada: " + title + " - " + price);
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Error parseando un item", e);
                }
            }
        } catch (IOException e) {
            Log.e(TAG, "Error al hacer scraping en " + DEALS_URL, e);
            return null;
        }
        return dealsList;
    }
}
