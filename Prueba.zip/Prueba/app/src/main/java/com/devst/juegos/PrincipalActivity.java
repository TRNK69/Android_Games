package com.devst.juegos;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.WriteBatch;

import java.util.List;

public class PrincipalActivity extends AppCompatActivity {

    private static final String TAG = "PrincipalActivity";
    private RecyclerView recyclerView;
    private GameAdapter adapter;
    private List<Game> gameList;
    private FirebaseFirestore db;
    private FirebaseAuth mAuth;

    private String currentStore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);

        currentStore = getIntent().getStringExtra("STORE_NAME");
        if (currentStore == null || currentStore.isEmpty()) {
            Toast.makeText(this, "Error: Tienda no especificada", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Ofertas de " + currentStore);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        recyclerView = findViewById(R.id.recyclerGames);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        gameList = new java.util.ArrayList<>();
        adapter = new GameAdapter(this, gameList);
        recyclerView.setAdapter(adapter);

        listenForGameUpdates();
    }

    private void listenForGameUpdates() {
        db.collection("games")
                .whereEqualTo("tienda", currentStore)
                .orderBy("nombre", Query.Direction.ASCENDING)
                .addSnapshotListener((value, error) -> {
                    if (error != null) {
                        Log.w(TAG, "Listen failed.", error);
                        return;
                    }
                    gameList.clear();
                    for (QueryDocumentSnapshot doc : value) {
                        gameList.add(doc.toObject(Game.class));
                    }
                    adapter.notifyDataSetChanged();
                    Log.d(TAG, "UI actualizada. Mostrando " + gameList.size() + " juegos de " + currentStore);
                });
    }

    private void updateDeals() {
        Toast.makeText(this, "Buscando ofertas en " + currentStore + "...", Toast.LENGTH_SHORT).show();
        Log.d(TAG, "updateDeals: Iniciando la llamada a la API para " + currentStore);

        if ("Steam".equals(currentStore)) {
            SteamApi.fetchSteamDeals(apiListener);
        } else if ("Epic Games".equals(currentStore)) {
            EpicApi.fetchEpicDeals(apiListener);
        }
    }

    private OnDealsFetchedListener apiListener = (games, storeName) -> {
        Log.d(TAG, "apiListener: Respuesta recibida de " + storeName);
        if (games != null && !games.isEmpty()) {
            Log.d(TAG, "apiListener: La respuesta contiene " + games.size() + " juegos. Procediendo a guardar.");
            saveDealsToFirestore(games, storeName);
        } else {
            Log.w(TAG, "apiListener: La respuesta de " + storeName + " está vacía o es nula.");
            Toast.makeText(this, "No se encontraron nuevas ofertas en " + storeName, Toast.LENGTH_SHORT).show();
        }
    };

    private void saveDealsToFirestore(List<Game> games, String storeName) {
        Log.d(TAG, "saveDealsToFirestore: Iniciando guardado para " + storeName);
        db.collection("games").whereEqualTo("tienda", storeName).get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                WriteBatch deleteBatch = db.batch();
                for (QueryDocumentSnapshot document : task.getResult()) {
                    deleteBatch.delete(document.getReference());
                }
                deleteBatch.commit().addOnCompleteListener(deleteTask -> {
                    if (deleteTask.isSuccessful()) {
                        Log.d(TAG, "saveDealsToFirestore: Juegos antiguos de " + storeName + " eliminados. Añadiendo nuevos...");
                        WriteBatch addBatch = db.batch();
                        for (Game game : games) {
                            addBatch.set(db.collection("games").document(), game);
                        }
                        addBatch.commit()
                                .addOnSuccessListener(aVoid -> {
                                    Log.d(TAG, "saveDealsToFirestore: ¡Éxito! Nuevos juegos de " + storeName + " guardados.");
                                    Toast.makeText(this, "Ofertas de " + storeName + " actualizadas.", Toast.LENGTH_SHORT).show();
                                })
                                .addOnFailureListener(e -> Log.e(TAG, "saveDealsToFirestore: Error al guardar nuevos juegos.", e));
                    }
                });
            }
        });
    }

    // --- Menu (se mantiene igual) ---
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.principal_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
            return true;
        }
        if (id == R.id.action_profile) {
            startActivity(new Intent(this, ProfileActivity.class));
            return true;
        }
        if (id == R.id.action_update_deals) {
            updateDeals();
            return true;
        }
        if (id == R.id.action_logout) {
            mAuth.signOut();
            Intent intent = new Intent(this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
