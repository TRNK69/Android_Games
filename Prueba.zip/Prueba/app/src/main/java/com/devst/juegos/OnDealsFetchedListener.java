package com.devst.juegos;

import java.util.List;

// Esta es nuestra nueva interfaz "universal"
public interface OnDealsFetchedListener {
    void onComplete(List<Game> games, String storeName);
}
