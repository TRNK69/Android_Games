package com.devst.juegos;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {

    private LinearLayout loginForm;
    private LinearLayout loadingLayout;
    private ProgressBar loadingBar;
    private TextView loadingPercentage;
    private EditText emailField;
    private EditText passwordField;
    private TextView registerTextView;
    private Handler handler = new Handler();
    private int progressStatus = 0;

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mAuth = FirebaseAuth.getInstance();

        loginForm = findViewById(R.id.login_form);
        loadingLayout = findViewById(R.id.loading_layout);
        loadingBar = findViewById(R.id.loading_bar);
        loadingPercentage = findViewById(R.id.loading_percentage);
        emailField = findViewById(R.id.email);
        passwordField = findViewById(R.id.password);
        Button loginButton = findViewById(R.id.login_button);
        registerTextView = findViewById(R.id.register_text_view);

        loginButton.setOnClickListener(v -> loginUser());

        registerTextView.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, RegisterActivity.class));
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser != null) {
            // ** CAMBIO: Ir a la selección de tienda **
            startActivity(new Intent(MainActivity.this, StoreSelectionActivity.class));
            finish();
        }
    }

    private void loginUser() {
        String email = emailField.getText().toString().trim();
        String password = passwordField.getText().toString().trim();

        if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Por favor, complete todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        loginForm.setVisibility(View.GONE);
        loadingLayout.setVisibility(View.VISIBLE);
        progressStatus = 0;

        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        new Thread(() -> {
                            while (progressStatus < 100) {
                                progressStatus += 1;
                                handler.post(() -> {
                                    loadingBar.setProgress(progressStatus);
                                    loadingPercentage.setText(progressStatus + "%");
                                });
                                try {
                                    Thread.sleep(20);
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                            }
                            handler.post(() -> {
                                // ** CAMBIO: Ir a la selección de tienda **
                                startActivity(new Intent(MainActivity.this, StoreSelectionActivity.class));
                                finish();
                            });
                        }).start();
                    } else {
                        Toast.makeText(MainActivity.this, "Error de autenticación: " + task.getException().getMessage(),
                                Toast.LENGTH_LONG).show();
                        loginForm.setVisibility(View.VISIBLE);
                        loadingLayout.setVisibility(View.GONE);
                    }
                });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loginForm.setVisibility(View.VISIBLE);
        loadingLayout.setVisibility(View.GONE);
    }
}
