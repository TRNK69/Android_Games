package com.devst.juegos;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AddGameActivity extends AppCompatActivity {

    private EditText nameEditText, imageUrlEditText, priceEditText, storeEditText, urlEditText;
    private Button saveButton;
    private DatabaseReference databaseReference;
    private String gameUidToEdit = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_game);

        // Apuntar a la nueva base de datos de ofertas
        databaseReference = FirebaseDatabase.getInstance().getReference("ofertas_juegos");

        nameEditText = findViewById(R.id.edit_game_name);
        imageUrlEditText = findViewById(R.id.edit_game_image_url);
        priceEditText = findViewById(R.id.edit_game_price);
        // Reutilizamos el campo de "precio oferta" para la tienda
        storeEditText = findViewById(R.id.edit_game_offer_price);
        urlEditText = findViewById(R.id.edit_game_url);
        saveButton = findViewById(R.id.button_save_game);

        storeEditText.setHint("Tienda"); // Cambiar la pista para que refleje el nuevo uso

        if (getIntent().hasExtra("game_uid")) {
            setTitle("Editar Juego");
            gameUidToEdit = getIntent().getStringExtra("game_uid");
            nameEditText.setText(getIntent().getStringExtra("game_name"));
            imageUrlEditText.setText(getIntent().getStringExtra("game_image_url"));
            priceEditText.setText(getIntent().getStringExtra("game_price"));
            storeEditText.setText(getIntent().getStringExtra("game_tienda"));
            urlEditText.setText(getIntent().getStringExtra("game_url"));
        } else {
            setTitle("Añadir Juego");
        }

        saveButton.setOnClickListener(v -> saveGame());
    }

    private void saveGame() {
        String name = nameEditText.getText().toString().trim();
        String imageUrl = imageUrlEditText.getText().toString().trim();
        String price = priceEditText.getText().toString().trim(); // Precio como String
        String store = storeEditText.getText().toString().trim(); // Tienda como String
        String url = urlEditText.getText().toString().trim();

        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(price)) {
            Toast.makeText(this, "Por favor, complete nombre y precio", Toast.LENGTH_SHORT).show();
            return;
        }

        // Usar el nuevo constructor que espera Strings
        Game game = new Game(name, imageUrl, price, store, url);

        if (gameUidToEdit != null) {
            databaseReference.child(gameUidToEdit).setValue(game);
            Toast.makeText(this, "Juego actualizado", Toast.LENGTH_SHORT).show();
        } else {
            String newGameUid = databaseReference.push().getKey();
            if (newGameUid != null) {
                databaseReference.child(newGameUid).setValue(game);
            }
            Toast.makeText(this, "Juego guardado", Toast.LENGTH_SHORT).show();
        }

        finish();
    }
}
