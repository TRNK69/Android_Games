package com.devst.juegos;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.FirebaseFirestore; // CAMBIO IMPORTANTE

public class AddGameActivity extends AppCompatActivity {

    private EditText nameEditText, imageUrlEditText, priceEditText, storeEditText, urlEditText;
    private Button saveButton;
    private FirebaseFirestore db; // CAMBIO IMPORTANTE
    private String gameUidToEdit = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_game);

        db = FirebaseFirestore.getInstance(); // CAMBIO IMPORTANTE

        nameEditText = findViewById(R.id.edit_game_name);
        imageUrlEditText = findViewById(R.id.edit_game_image_url);
        priceEditText = findViewById(R.id.edit_game_price);
        storeEditText = findViewById(R.id.edit_game_offer_price);
        urlEditText = findViewById(R.id.edit_game_url);
        saveButton = findViewById(R.id.button_save_game);

        storeEditText.setHint("Tienda");

        if (getIntent().hasExtra("game_uid")) {
            setTitle("Editar Juego");
            gameUidToEdit = getIntent().getStringExtra("game_uid");
            nameEditText.setText(getIntent().getStringExtra("game_name"));
            imageUrlEditText.setText(getIntent().getStringExtra("game_image_url"));
            priceEditText.setText(getIntent().getStringExtra("game_price"));
            storeEditText.setText(getIntent().getStringExtra("game_tienda"));
            urlEditText.setText(getIntent().getStringExtra("game_url"));
        } else {
            setTitle("Añadir Juego");
        }

        saveButton.setOnClickListener(v -> saveGame());
    }

    private void saveGame() {
        String name = nameEditText.getText().toString().trim();
        String imageUrl = imageUrlEditText.getText().toString().trim();
        String price = priceEditText.getText().toString().trim();
        String store = storeEditText.getText().toString().trim();
        String url = urlEditText.getText().toString().trim();

        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(price)) {
            Toast.makeText(this, "Por favor, complete nombre y precio", Toast.LENGTH_SHORT).show();
            return;
        }

        Game game = new Game(name, imageUrl, price, store, url);

        // CAMBIO IMPORTANTE: Lógica para guardar en Firestore
        if (gameUidToEdit != null) {
            // Actualizar un juego existente
            db.collection("games").document(gameUidToEdit).set(game)
                    .addOnSuccessListener(aVoid -> {
                        Toast.makeText(this, "Juego actualizado", Toast.LENGTH_SHORT).show();
                        finish();
                    })
                    .addOnFailureListener(e -> Toast.makeText(this, "Error al actualizar el juego", Toast.LENGTH_SHORT).show());
        } else {
            // Añadir un juego nuevo
            db.collection("games").add(game)
                    .addOnSuccessListener(documentReference -> {
                        Toast.makeText(this, "Juego guardado", Toast.LENGTH_SHORT).show();
                        finish();
                    })
                    .addOnFailureListener(e -> Toast.makeText(this, "Error al guardar el juego", Toast.LENGTH_SHORT).show());
        }
    }
}
