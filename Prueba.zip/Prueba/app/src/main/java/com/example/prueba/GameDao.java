package com.example.prueba;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class GameDao {

    private GameDatabase dbHelper;

    public GameDao(Context context) {
        dbHelper = new GameDatabase(context);
    }

    public long insert(Game game) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("nombre", game.getNombre());
        values.put("imagenUrl", game.getImagenUrl());
        values.put("precio", game.getPrecio());
        values.put("precioOferta", game.getPrecioOferta());
        values.put("url", game.getUrl());

        long id = db.insert("games", null, values);
        db.close();
        return id;
    }

    public int update(Game game) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("nombre", game.getNombre());
        values.put("imagenUrl", game.getImagenUrl());
        values.put("precio", game.getPrecio());
        values.put("precioOferta", game.getPrecioOferta());
        values.put("url", game.getUrl());

        return db.update("games", values, "id = ?", new String[]{String.valueOf(game.getId())});
    }

    public void delete(int gameId) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.delete("games", "id = ?", new String[]{String.valueOf(gameId)});
        db.close();
    }

    public Game getGameById(int id) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor c = db.query("games", null, "id = ?", new String[]{String.valueOf(id)}, null, null, null);
        if (c != null && c.moveToFirst()) {
            String nombre = c.getString(c.getColumnIndexOrThrow("nombre"));
            String imagen = c.getString(c.getColumnIndexOrThrow("imagenUrl"));
            int precio = c.getInt(c.getColumnIndexOrThrow("precio"));
            int precioOferta = c.getInt(c.getColumnIndexOrThrow("precioOferta"));
            String url = c.getString(c.getColumnIndexOrThrow("url"));
            Game game = new Game(id, nombre, imagen, precio, precioOferta, url);
            c.close();
            db.close();
            return game;
        }
        return null;
    }

    public List<Game> getAll() {
        List<Game> lista = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM games", null);

        if (c.moveToFirst()) {
            do {
                int id = c.getInt(c.getColumnIndexOrThrow("id"));
                String nombre = c.getString(c.getColumnIndexOrThrow("nombre"));
                String imagen = c.getString(c.getColumnIndexOrThrow("imagenUrl"));
                int precio = c.getInt(c.getColumnIndexOrThrow("precio"));
                int precioOferta = c.getInt(c.getColumnIndexOrThrow("precioOferta"));
                String url = c.getString(c.getColumnIndexOrThrow("url"));
                lista.add(new Game(id, nombre, imagen, precio, precioOferta, url));
            } while (c.moveToNext());
        }
        c.close();
        db.close();
        return lista;
    }

    public void clear() {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.delete("games", null, null); // borrar todo
        db.close();
    }
}
