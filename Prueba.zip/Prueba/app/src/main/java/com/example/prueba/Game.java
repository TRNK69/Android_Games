package com.example.prueba;

public class Game {
    private int id;
    private String nombre;
    private String imagenUrl;
    private int precio;
    private int precioOferta;
    private String url;

    public Game(int id, String nombre, String imagenUrl, int precio, int precioOferta, String url) {
        this.id = id;
        this.nombre = nombre;
        this.imagenUrl = imagenUrl;
        this.precio = precio;
        this.precioOferta = precioOferta;
        this.url = url;
    }

    public Game(String nombre, String imagenUrl, int precio, int precioOferta, String url) {
        this.nombre = nombre;
        this.imagenUrl = imagenUrl;
        this.precio = precio;
        this.precioOferta = precioOferta;
        this.url = url;
    }

    // Getters
    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public String getImagenUrl() { return imagenUrl; }
    public int getPrecio() { return precio; }
    public int getPrecioOferta() { return precioOferta; }
    public String getUrl() { return url; }

    // Setters
    public void setId(int id) { this.id = id; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setImagenUrl(String imagenUrl) { this.imagenUrl = imagenUrl; }
    public void setPrecio(int precio) { this.precio = precio; }
    public void setPrecioOferta(int precioOferta) { this.precioOferta = precioOferta; }
    public void setUrl(String url) { this.url = url; }
}
