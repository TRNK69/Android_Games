package com.example.prueba;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class GameAdapter extends RecyclerView.Adapter<GameAdapter.GameViewHolder> {

    private Context context;
    private List<Game> games;
    private OnGameListener onGameListener;

    public interface OnGameListener {
        void onEditClick(Game game);
        void onDeleteClick(Game game);
    }

    public GameAdapter(Context context, List<Game> games, OnGameListener onGameListener) {
        this.context = context;
        this.games = games;
        this.onGameListener = onGameListener;
    }

    @NonNull
    @Override
    public GameViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_game, parent, false);
        return new GameViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull GameViewHolder holder, int position) {
        Game game = games.get(position);

        holder.name.setText(game.getNombre());
        holder.price.setText("Precio: $" + game.getPrecio());
        holder.salePrice.setText("Oferta: $" + game.getPrecioOferta());

        Glide.with(context)
                .load(game.getImagenUrl())
                .placeholder(R.drawable.ic_launcher_background)
                .error(R.drawable.boton_bd_presionado)
                .into(holder.image);

        holder.itemView.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(game.getUrl()));
            context.startActivity(i);
        });

        holder.editButton.setOnClickListener(v -> {
            if (onGameListener != null) {
                onGameListener.onEditClick(game);
            }
        });

        holder.deleteButton.setOnClickListener(v -> {
            if (onGameListener != null) {
                onGameListener.onDeleteClick(game);
            }
        });
    }

    @Override
    public int getItemCount() {
        return games.size();
    }

    public static class GameViewHolder extends RecyclerView.ViewHolder {

        ImageView image;
        TextView name, price, salePrice;
        Button editButton, deleteButton;

        public GameViewHolder(@NonNull View itemView) {
            super(itemView);
            image = itemView.findViewById(R.id.gameImage);
            name = itemView.findViewById(R.id.gameName);
            price = itemView.findViewById(R.id.gamePrice);
            salePrice = itemView.findViewById(R.id.gameSalePrice);
            editButton = itemView.findViewById(R.id.edit_button);
            deleteButton = itemView.findViewById(R.id.delete_button);
        }
    }
}
