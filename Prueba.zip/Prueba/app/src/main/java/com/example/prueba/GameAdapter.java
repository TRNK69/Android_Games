package com.example.prueba;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class GameAdapter extends RecyclerView.Adapter<GameAdapter.GameViewHolder> {

    private Context context;
    private List<Game> games;

    public GameAdapter(Context context, List<Game> games) {
        this.context = context;
        this.games = games;
    }

    @NonNull
    @Override
    public GameViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_game, parent, false);
        return new GameViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull GameViewHolder holder, int position) {
        Game game = games.get(position);

        holder.name.setText(game.getNombre());
        holder.price.setText("Precio: $" + game.getPrecio());
        holder.salePrice.setText("Oferta: $" + game.getPrecioOferta());

        // Cargar imagen con Glide, incluyendo placeholder y error
        Glide.with(context)
                .load(game.getImagenUrl())
                .placeholder(R.drawable.ic_launcher_background) // Imagen de carga
                .error(R.drawable.boton_bd_presionado) // Imagen si hay error
                .into(holder.image);

        // Abrir enlace del juego
        holder.itemView.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(game.getUrl()));
            context.startActivity(i);
        });
    }

    @Override
    public int getItemCount() {
        return games.size();
    }

    public static class GameViewHolder extends RecyclerView.ViewHolder {

        ImageView image;
        TextView name, price, salePrice;

        public GameViewHolder(@NonNull View itemView) {
            super(itemView);
            image = itemView.findViewById(R.id.gameImage);
            name = itemView.findViewById(R.id.gameName);
            price = itemView.findViewById(R.id.gamePrice);
            salePrice = itemView.findViewById(R.id.gameSalePrice);
        }
    }
}
