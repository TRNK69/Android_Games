package com.example.prueba;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddGameActivity extends AppCompatActivity {

    private EditText nameEditText, imageUrlEditText, priceEditText, offerPriceEditText, urlEditText;
    private Button saveButton;
    private GameDao gameDao;
    private Game gameToEdit = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_game);

        gameDao = new GameDao(this);

        nameEditText = findViewById(R.id.edit_game_name);
        imageUrlEditText = findViewById(R.id.edit_game_image_url);
        priceEditText = findViewById(R.id.edit_game_price);
        offerPriceEditText = findViewById(R.id.edit_game_offer_price);
        urlEditText = findViewById(R.id.edit_game_url);
        saveButton = findViewById(R.id.button_save_game);

        if (getIntent().hasExtra("GAME_ID")) {
            setTitle("Editar Juego");
            int gameId = getIntent().getIntExtra("GAME_ID", -1);
            loadGameData(gameId);
        } else {
            setTitle("Añadir Juego");
        }

        saveButton.setOnClickListener(v -> saveGame());
    }

    private void loadGameData(int gameId) {
        new AsyncTask<Integer, Void, Game>() {
            @Override
            protected Game doInBackground(Integer... ids) {
                return gameDao.getGameById(ids[0]);
            }

            @Override
            protected void onPostExecute(Game game) {
                if (game != null) {
                    gameToEdit = game;
                    nameEditText.setText(game.getNombre());
                    imageUrlEditText.setText(game.getImagenUrl());
                    priceEditText.setText(String.valueOf(game.getPrecio()));
                    offerPriceEditText.setText(String.valueOf(game.getPrecioOferta()));
                    urlEditText.setText(game.getUrl());
                }
            }
        }.execute(gameId);
    }

    private void saveGame() {
        String name = nameEditText.getText().toString();
        String imageUrl = imageUrlEditText.getText().toString();
        String priceStr = priceEditText.getText().toString();
        String offerPriceStr = offerPriceEditText.getText().toString();
        String url = urlEditText.getText().toString();

        if (name.isEmpty() || priceStr.isEmpty() || offerPriceStr.isEmpty()) {
            Toast.makeText(this, "Por favor, complete los campos obligatorios", Toast.LENGTH_SHORT).show();
            return;
        }

        int price = Integer.parseInt(priceStr);
        int offerPrice = Integer.parseInt(offerPriceStr);

        final Game game = new Game(name, imageUrl, price, offerPrice, url);

        new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... voids) {
                if (gameToEdit != null) {
                    game.setId(gameToEdit.getId());
                    gameDao.update(game);
                } else {
                    gameDao.insert(game);
                }
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                Toast.makeText(AddGameActivity.this, "Juego guardado", Toast.LENGTH_SHORT).show();
                setResult(RESULT_OK);
                finish();
            }
        }.execute();
    }
}
