
package com.example.prueba;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.example.prueba.DB.DatabaseHelper;

public class MainActivity extends AppCompatActivity {

    private LinearLayout loginForm;
    private LinearLayout loadingLayout;
    private ProgressBar loadingBar;
    private TextView loadingPercentage;
    private EditText emailField;
    private EditText passwordField;
    private TextView registerTextView;
    private Handler handler = new Handler();
    private int progressStatus = 0;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);

        loginForm = findViewById(R.id.login_form);
        loadingLayout = findViewById(R.id.loading_layout);
        loadingBar = findViewById(R.id.loading_bar);
        loadingPercentage = findViewById(R.id.loading_percentage);
        emailField = findViewById(R.id.email);
        passwordField = findViewById(R.id.password);
        Button loginButton = findViewById(R.id.login_button);
        registerTextView = findViewById(R.id.register_text_view);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = emailField.getText().toString();
                String password = passwordField.getText().toString();

                if (dbHelper.checkUser(email, password)) {
                    // Credenciales correctas: iniciar animación de carga
                    loginForm.setVisibility(View.GONE);
                    loadingLayout.setVisibility(View.VISIBLE);
                    progressStatus = 0;

                    new Thread(new Runnable() {
                        public void run() {
                            while (progressStatus < 100) {
                                progressStatus += 1;
                                handler.post(new Runnable() {
                                    public void run() {
                                        loadingBar.setProgress(progressStatus);
                                        loadingPercentage.setText(progressStatus + "%");
                                    }
                                });
                                try {
                                    Thread.sleep(20);
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                            }
                            handler.post(new Runnable() {
                                public void run() {
                                    Intent intent = new Intent(MainActivity.this, PrincipalActivity.class);
                                    startActivity(intent);
                                }
                            });
                        }
                    }).start();
                } else {
                    // Credenciales incorrectas: mostrar error
                    emailField.setError("Credenciales incorrectas");
                    passwordField.setError("Credenciales incorrectas");
                }
            }
        });

        registerTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loginForm.setVisibility(View.VISIBLE);
        loadingLayout.setVisibility(View.GONE);
        progressStatus = 0;
        loadingBar.setProgress(0);
        loadingPercentage.setText("0%");
        // Limpiar errores al volver a la pantalla
        emailField.setError(null);
        passwordField.setError(null);
    }
}
