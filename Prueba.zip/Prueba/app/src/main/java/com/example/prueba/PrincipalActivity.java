package com.example.prueba;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class PrincipalActivity extends AppCompatActivity {

    private static final int ADD_GAME_REQUEST = 1;
    private RecyclerView recyclerView;
    private GameAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        recyclerView = findViewById(R.id.recyclerGames);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        FloatingActionButton fab = findViewById(R.id.fab_add_game);
        fab.setOnClickListener(view -> {
            Intent intent = new Intent(PrincipalActivity.this, AddGameActivity.class);
            startActivityForResult(intent, ADD_GAME_REQUEST);
        });

        updateGamesIfNeeded();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == ADD_GAME_REQUEST && resultCode == RESULT_OK) {
            loadGames(); // Recargar la lista si se añadió un juego
        }
    }

    // --- Descarga juegos solo si no hay datos ---
    private void updateGamesIfNeeded() {
        new AsyncTask<Void, Void, Integer>() {

            @Override
            protected Integer doInBackground(Void... voids) {
                GameDao dao = new GameDao(PrincipalActivity.this);
                List<Game> lista = dao.getAll();

                if (lista.size() == 0) {
                    // La BD está vacía → descargar juegos
                    List<Game> nuevos = GameScraper.getRandomGames(10);

                    if (nuevos == null) {
                        return -1; // Error en el scraping
                    }

                    for (Game g : nuevos) {
                        dao.insert(g);
                    }
                    return 1; // Se actualizaron los juegos
                }

                return 0; // No se hizo nada
            }

            @Override
            protected void onPostExecute(Integer result) {
                if (result == -1) {
                    Toast.makeText(PrincipalActivity.this, "Error al descargar los juegos. Revisa tu conexión a internet.", Toast.LENGTH_LONG).show();
                }
                loadGames();
            }
        }.execute();
    }

    // --- Carga los juegos desde SQLite ---
    private void loadGames() {
        new AsyncTask<Void, Void, List<Game>>() {
            @Override
            protected List<Game> doInBackground(Void... voids) {
                GameDao dao = new GameDao(PrincipalActivity.this);
                return dao.getAll();
            }

            @Override
            protected void onPostExecute(List<Game> games) {
                Log.d("DEBUG_JUEGOS", "Juegos cargados desde SQLite: " + games.size());

                adapter = new GameAdapter(PrincipalActivity.this, games);
                recyclerView.setAdapter(adapter);
            }

        }.execute();
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}