package com.example.prueba;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class PrincipalActivity extends AppCompatActivity implements GameAdapter.OnGameListener {

    private static final int ADD_GAME_REQUEST = 1;
    private static final int EDIT_GAME_REQUEST = 2;
    private RecyclerView recyclerView;
    private GameAdapter adapter;
    private GameDao gameDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        recyclerView = findViewById(R.id.recyclerGames);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        gameDao = new GameDao(this);

        FloatingActionButton fab = findViewById(R.id.fab_add_game);
        fab.setOnClickListener(view -> {
            Intent intent = new Intent(PrincipalActivity.this, AddGameActivity.class);
            startActivityForResult(intent, ADD_GAME_REQUEST);
        });

        updateGamesIfNeeded();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if ((requestCode == ADD_GAME_REQUEST || requestCode == EDIT_GAME_REQUEST) && resultCode == RESULT_OK) {
            loadGames(); // Recargar la lista si se añadió o editó un juego
        }
    }

    private void updateGamesIfNeeded() {
        new AsyncTask<Void, Void, Integer>() {
            @Override
            protected Integer doInBackground(Void... voids) {
                if (gameDao.getAll().isEmpty()) {
                    List<Game> nuevos = GameScraper.getRandomGames(10);
                    if (nuevos == null) {
                        return -1; // Error
                    }
                    for (Game g : nuevos) {
                        gameDao.insert(g);
                    }
                    return 1; // Actualizado
                }
                return 0; // No se hizo nada
            }

            @Override
            protected void onPostExecute(Integer result) {
                if (result == -1) {
                    Toast.makeText(PrincipalActivity.this, "Error al descargar los juegos.", Toast.LENGTH_LONG).show();
                }
                loadGames();
            }
        }.execute();
    }

    private void loadGames() {
        new AsyncTask<Void, Void, List<Game>>() {
            @Override
            protected List<Game> doInBackground(Void... voids) {
                return gameDao.getAll();
            }

            @Override
            protected void onPostExecute(List<Game> games) {
                adapter = new GameAdapter(PrincipalActivity.this, games, PrincipalActivity.this);
                recyclerView.setAdapter(adapter);
            }
        }.execute();
    }

    @Override
    public void onEditClick(Game game) {
        Intent intent = new Intent(this, AddGameActivity.class);
        intent.putExtra("GAME_ID", game.getId());
        startActivityForResult(intent, EDIT_GAME_REQUEST);
    }

    @Override
    public void onDeleteClick(Game game) {
        new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... voids) {
                gameDao.delete(game.getId());
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                loadGames();
                Toast.makeText(PrincipalActivity.this, "Juego eliminado", Toast.LENGTH_SHORT).show();
            }
        }.execute();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
