package com.example.prueba;

import android.util.Log;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class GameScraper {

    private static final String URL = "https://www.keysforgames.cl/games/steam-games/";
    private static final String BASE_URL = "https://www.keysforgames.cl";

    public static List<Game> scrape() {
        List<Game> juegos = new ArrayList<>();

        try {
            Log.d("GameScraper", "Iniciando scraping de: " + URL);
            Document doc = Jsoup.connect(URL).get();
            Log.d("GameScraper", "HTML descargado con éxito.");

            Elements items = doc.select("div.item-inner");
            Log.d("GameScraper", "Se encontraron " + items.size() + " elementos con 'div.item-inner'.");

            if (items.isEmpty()) {
                Log.w("GameScraper", "El selector 'div.item-inner' no encontró resultados.");
                return juegos;
            }

            for (Element item : items) {
                String nombre = item.select("h2.product-name a").text();
                String imagen = item.select("img.product-image-photo").attr("src");
                String enlace = item.select("h2.product-name a").attr("href");

                // Asegurarse de que las URLs son absolutas
                if (!imagen.startsWith("http")) {
                    imagen = BASE_URL + imagen;
                }
                if (!enlace.startsWith("http")) {
                    enlace = BASE_URL + enlace;
                }

                String precioStr = item.select(".price-box .price").text()
                        .replace("$", "").replace(".", "").trim();

                if (precioStr.isEmpty()) {
                    continue;
                }

                int precio = Integer.parseInt(precioStr);
                int oferta = precio; // No hay precio de oferta claro

                Log.d("GameScraper", "Juego encontrado: " + nombre + " | Imagen: " + imagen);
                juegos.add(new Game(nombre, imagen, precio, oferta, enlace));
            }

        } catch (Exception e) {
            Log.e("GameScraper", "Error durante el scraping", e);
            return null;
        }

        return juegos;
    }

    public static List<Game> getRandomGames(int cantidad) {
        List<Game> todos = scrape();

        if (todos == null) {
            return null;
        }

        if (todos.isEmpty()) {
            return todos;
        }

        Collections.shuffle(todos);
        return todos.subList(0, Math.min(cantidad, todos.size()));
    }
}
